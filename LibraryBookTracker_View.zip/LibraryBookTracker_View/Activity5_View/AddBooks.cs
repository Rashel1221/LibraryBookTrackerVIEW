﻿using Activity5_View.Models;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity5_View
{
    public partial class AddBooks : Form
    {
        private static readonly HttpClient client = new HttpClient();
        public AddBooks()
        {
            InitializeComponent();
        }

        // Method to clear input fields
        private void ClearFields()
        {
            txtTitle.Clear();
            txtAuthor.Clear();
            txtISBN.Clear();
            txtGenre.Clear();
            nupAvailability.Value = 0; // Reset to default
        }
        private async void btnAdd_Click(object sender, EventArgs e)
        {
            var newBook = new Book
            {
                Title = txtTitle.Text, // Assume txtTitle is a TextBox for Title
                Author = txtAuthor.Text, // Assume txtAuthor is a TextBox for Author
                ISBN = txtISBN.Text, // Assume txtISBN is a TextBox for ISBN
                Genre = txtGenre.Text, // Assume txtGenre is a TextBox for Genre
                PublicationYear = txtYear.Text, // Assume txtPublicationYear is a TextBox for Publication Year
                Availability = (int)nupAvailability.Value // Assume numericUpDownAvailability is a NumericUpDown control
            };

            // Send the new book to the API
            try
            {
                string url = "http://localhost:5101/api/Book"; // Replace with your actual API URL
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(newBook);
                var content = new StringContent(json, Encoding.UTF8, "application/json");

                var response = await client.PostAsync(url, content);

                if (response.IsSuccessStatusCode)
                {
                    MessageBox.Show("Book added successfully!");
                    // Optionally, clear the fields after adding
                    ClearFields();
                    // Optionally, reload the books to show the new entry
                
                }
                else
                {
                    MessageBox.Show($"Error adding book: {response.ReasonPhrase}");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}");
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            BookManagement form = new BookManagement();
            form.Show();
            this.Hide();

        }
    }
}
