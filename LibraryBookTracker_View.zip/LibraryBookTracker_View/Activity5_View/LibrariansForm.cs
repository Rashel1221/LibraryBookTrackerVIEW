﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity5_View
{
    public partial class LibrariansForm : Form
    {
        public LibrariansForm()
        {
            InitializeComponent();
        }

        private void btnBook_Click(object sender, EventArgs e)
        {
            BookManagement form = new BookManagement();
            form.Show();
            this.Hide();
        }
    }
}
