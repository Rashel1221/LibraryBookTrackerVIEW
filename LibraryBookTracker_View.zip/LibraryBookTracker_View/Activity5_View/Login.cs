﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Activity5_View
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnLogin_Click_1(object sender, EventArgs e)
        {
            if (txtUsername.Text == "rashel")
            {
                lblUserChk.Visible = false;
                txtUsername.Focus();
            }
            else
            {
                lblUserChk.Visible = true;
                txtUsername.Focus();
            }
            if (txtPW.Text == "1432")
            {
                lblPWChk.Visible = false;
                txtUsername.Focus();
            }
            else
            {
                lblPWChk.Visible = true;
                txtUsername.Focus();
            }
            if (txtUsername.Text == "rashel" && txtPW.Text == "1432")
            {
                LibrariansForm form = new LibrariansForm();
                form.Show();
                this.Hide();
            }
        }
    }
}
