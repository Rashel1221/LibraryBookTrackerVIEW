﻿using Activity5_View.Models;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Linq;

namespace Activity5_View
{
    public partial class BookManagement : Form
    {
        private static readonly HttpClient client = new HttpClient();
        public BookManagement()
        {
            InitializeComponent();
            btnDelete.Click += btnDelete_Click;
            btnUpdate.Click += btnUpdate_Click;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private async Task<List<Book>> GetBooksAsync()
        {
            try
            {
                string url = "http://localhost:5022/api/Book/GetAllBooks"; // Replace with your actual API URL

                // Asynchronous call to fetch data from API
                var response = await client.GetStringAsync(url);

                // Deserialization into List<Book>
                return Newtonsoft.Json.JsonConvert.DeserializeObject<List<Book>>(response);
            }
            catch (Exception ex)
            {
                // Error handling - could be more specific
                MessageBox.Show($"Error fetching data: {ex.Message}");
                return new List<Book>(); // Return an empty list to avoid null reference
            }
        }
        private async void btnLoadBooks_Click(object sender, EventArgs e)
        {
            var books = await GetBooksAsync();

            if (books != null && books.Any())
            {
                dgvBooks.DataSource = books; // Bind books to DataGridView
            }
            else
            {
                MessageBox.Show("No books available or failed to load data.");
            }
        }

        private async Task<bool> AddBookAsync(Book book)
        {
            try
            {
                string url = "http://localhost:5022/api/Book/GetAllBooks"; // Adjust URL as necessary
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(book);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                var response = await client.PostAsync(url, content);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding book: {ex.Message}");
                return false;
            }
        }
        private async Task<Book> GetBookByIdAsync(int bookId)
        {
            try
            {
                string url = $"http://localhost:5022/api/Book/GetAllBooks{bookId}"; // Adjust URL as necessary
                var response = await client.GetStringAsync(url);
                return Newtonsoft.Json.JsonConvert.DeserializeObject<Book>(response);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error fetching book: {ex.Message}");
                return null;
            }
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddBooks addform = new AddBooks();
            addform.Show();
            this.Hide();
        }

        private async Task<bool> DeleteBookAsync(int bookId)
        {
            try
            {
                string url = $"http://localhost:5022/api/Book/GetAllBooks{bookId}"; // Adjust URL as necessary
                var response = await client.DeleteAsync(url);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error deleting book: {ex.Message}");
                return false;
            }
        }

        private async void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvBooks.SelectedRows.Count > 0)
            {
                var selectedRow = dgvBooks.SelectedRows[0];
                int bookId = (int)selectedRow.Cells["BookID"].Value; // Assuming "BookID" is a column in your DataGridView

                bool isSuccess = await DeleteBookAsync(bookId);
                if (isSuccess)
                {
                    MessageBox.Show("Book deleted successfully!");
                    // Refresh the DataGridView
                    var books = await GetBooksAsync();
                    if (books != null)
                    {
                        dgvBooks.DataSource = books;
                    }
                }
                else
                {
                    MessageBox.Show("Failed to delete the book.");
                }
            }
            else
            {
                MessageBox.Show("Please select a book to delete.");
            }
        }

        private async Task<bool> UpdateBookAsync(Book book)
        {
            try
            {
                string url = $"http://localhost:5022/api/Book/GetAllBooks{book.BookID}"; // Adjust URL as necessary
                var json = Newtonsoft.Json.JsonConvert.SerializeObject(book);
                var content = new StringContent(json, System.Text.Encoding.UTF8, "application/json");

                var response = await client.PutAsync(url, content);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating book: {ex.Message}");
                return false;
            }
        }

        private async void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvBooks.SelectedRows.Count > 0)
            {
                var selectedRow = dgvBooks.SelectedRows[0];
                var book = new Book
                {
                    BookID = (int)selectedRow.Cells["BookID"].Value,
                    Title = selectedRow.Cells["Title"].Value?.ToString(),
                    Author = selectedRow.Cells["Author"].Value?.ToString(),
                    ISBN = selectedRow.Cells["ISBN"].Value?.ToString(),
                    Genre = selectedRow.Cells["Genre"].Value?.ToString(),
                    PublicationYear = selectedRow.Cells["PublicationYear"].Value?.ToString(),
                    Availability = (int)selectedRow.Cells["Availability"].Value
                };

                var result = MessageBox.Show("Do you want to update this book?", "Confirm Update", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    bool isSuccess = await UpdateBookAsync(book);
                    if (isSuccess)
                    {
                        MessageBox.Show("Book updated successfully!");
                        // Refresh the DataGridView
                        var books = await GetBooksAsync();
                        if (books != null)
                        {
                            dgvBooks.DataSource = books;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Failed to update the book.");
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select a book to update.");
            }
        }
        private async void btnGetID_Click(object sender, EventArgs e)
        {
            string input = Microsoft.VisualBasic.Interaction.InputBox("Enter Book ID:", "Fetch Book");

            if (int.TryParse(input, out int bookId))
            {
                var book = await GetBookByIdAsync(bookId);
                if (book != null)
                {
                    var books = new List<Book> { book }; // Create a list with the book
                    dgvBooks.DataSource = books; // Bind to DataGridView
                }
                else
                {
                    MessageBox.Show("Book not found.");
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid Book ID.");
            }
        }
    }
}
