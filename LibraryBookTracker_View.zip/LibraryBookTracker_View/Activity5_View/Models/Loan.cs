﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Activity5_View.Models
{
    public class Loan
    {
        public int LoanID { get; set; }

        public string BookID { get; set; }

        public string PatronID { get; set; }

        public DateTime LoanDate { get; set; }

        public DateTime DueDate { get; set; }

        public DateTime? ReturnDate { get; set; }

        public int Status { get; set; }
    }
}
